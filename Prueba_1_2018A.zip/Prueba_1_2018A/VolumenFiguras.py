# definimos la funcion cubo
import math
def VolumenCubo():
    print("\n\t\tCubo")
    lado = (float)(input("Introduzca un lado del cubo: "))
    volumencubo = math.pow(lado,3)
    print("El volumen del cubo es: ",'%.2f' % volumencubo , "m^3")

    # Volumen de una piramide
    # Xavier Jaramillo

def VolumenPiramide():
        print("Volumen de una piramide triangular")
        base = (float)(input("Introduzca la base: "))
        altura = (float)(input("Introduzca la altura: "))

        volumen = (base * altura) / 3
        print("El volumen de la piramide es: ", '%.2f' % volumen, "m^3")
# Definimos la funcion menu con las opciones

def menu():
    print("\nMenu\n"
          +"1.VolumenCubo\n"
          +"2.Volumen de Piramide de base triangular\n"
          +"3.Volumen----\n"
          +"4.Salir\n")

# Menu de opciones para usarlas
def MenuFiguras():
    # Inicalizacion de la variable opciones
    opciones = 0
    print("\t\tBienvenido")

    # Uso de while para crear un repeticion de menu
    while opciones != 4:
        # Llamamos a la funcion menu
        menu()
        # Introducimos la opcion en int
        opciones = (int)(input("Elija una opcion: "))
        if opciones == 1:
        # Llamamos a la funcion cubo para realizar la operacion del volumen
            VolumenCubo();
        if opciones == 2:
            VolumenPiramide();
        elif opciones == 4:
            print("Gracias por usar el programa")
        else:
            print("Ingrese una opcion valida")

MenuFiguras()